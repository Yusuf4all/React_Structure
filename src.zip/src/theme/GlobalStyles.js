import { createGlobalStyle } from "styled-components";

export const GlobalStyles = createGlobalStyle`
    :root {
        --font-thin: ${({ theme }) => theme.font.thin};
        --font-light: ${({ theme }) => theme.font.light};
        --font-medium: ${({ theme }) => theme.font.medium};
        --font-regular: ${({ theme }) => theme.font.regular};
        --font-bold: ${({ theme }) => theme.font.bold};

        --primary: ${({ theme }) => theme.colors.primary};
        --primary-dark: ${({ theme }) => theme.colors.primaryDark};
        --secondary: ${({ theme }) => theme.colors.secondary};
        --text-primary: ${({ theme }) => theme.colors.textPrimary};
        --text-secondary: ${({ theme }) => theme.colors.textSecondary};
        --nav-primary: ${({ theme }) => theme.colors.navPrimary};
        --nav-secondary: ${({ theme }) => theme.colors.navSecondary};
        --nav-text-primary: ${({ theme }) => theme.colors.navTextPrimary};
        --card-primary: ${({ theme }) => theme.colors.cardPrimary};
        --card-primary-light: ${({ theme }) => theme.colors.cardPrimaryLight};
        --card-primary-dark: ${({ theme }) => theme.colors.cardPrimaryDark};
        --btn-default: ${({ theme }) => theme.colors.btnDefault};
        --btn-primary: ${({ theme }) => theme.colors.btnPrimary};
        --btn-secondary: ${({ theme }) => theme.colors.btnSecondary};
        --btn-secondary-dark: ${({ theme }) => theme.colors.btnSecondaryDark};
        --success: ${({ theme }) => theme.colors.sucess}; 
        --footer-primary: ${({ theme }) => theme.colors.footerPrimary};
        --footer-text-primary: ${({ theme }) => theme.colors.footerTextPrimary};
    }
`;