import React, { useState, useEffect } from "react";
import { ThemeProvider } from "styled-components";
import { useTheme } from "./UseTheme";

const MultiThemeProvider = (props) => {
	const { theme, themeLoaded } = useTheme();
	const [selectedTheme, setSelectedTheme] = useState(theme);

    useEffect(() => {
		setSelectedTheme(theme);
		const applyConfigurations = async () => {
			document.title = theme.title;
			const favicon = document.getElementById("favicon");
			favicon.href = `${theme.favIconUrl}`;
		};
		applyConfigurations();
	}, [theme]);

	return (
		<ThemeProvider theme={selectedTheme}>
			{themeLoaded && props.children}
		</ThemeProvider>
	);
};

export default MultiThemeProvider;
