import { useEffect, useState } from 'react';
import _ from 'lodash';

// import UserContext from '../hooks/UserContext';
import { DEFAULT_THEME } from "../utils/Constants";

export const useTheme = () => {
    // const user = useContext(UserContext);
    const user = null;
    const currentTheme = (process.env.REACT_APP_MU_THEME === "true" && user?.configuration && !_.isEmpty(user.configuration)) ? user.configuration : DEFAULT_THEME;
    const [theme, setTheme] = useState(currentTheme);
    const [themeLoaded, setThemeLoaded] = useState(false);

    useEffect(() => {
        setTheme(currentTheme); // Change theme according tenant
        setThemeLoaded(true);
    }, [user, currentTheme]);
    
    return { theme, themeLoaded };
};