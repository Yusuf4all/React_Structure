import httpClient from "../xhr";
const controller = new AbortController();

async function get(url, options = {}) {
	try {
		const OPTION_WRAPPER = { ...options, signal: controller.signal };
		const res = await httpClient.get(`${url}`, OPTION_WRAPPER);
		return await res.data;
	} catch (error) {
		return error;
	}
}

async function post(url, payload, options = {}) {
	try {
		const OPTION_WRAPPER = { ...options, signal: controller.signal };
		const res = await httpClient.post(`${url}`, payload, OPTION_WRAPPER);
		return await res.data;
	} catch (error) {
		return error;
	}
}

async function put(url, payload, options = {}) {
	try {
		const OPTION_WRAPPER = { ...options, signal: controller.signal };
		const res = await httpClient.put(`${url}`, payload, OPTION_WRAPPER);
		return await res.data;
	} catch (error) {
		return error;
	}
}

export const MasterService = {
	get,
	post,
	put
};
