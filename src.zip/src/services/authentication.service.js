import { BehaviorSubject } from 'rxjs';
import Utils from '../utils'
import Auth from '../utils/auth'

const currentUserSubject = new BehaviorSubject(Auth.getToken());
export const authenticationService = {
    loginData,
    logout,
    currentUser: currentUserSubject.asObservable(),
    get currentUserValue() { return currentUserSubject.value }
};

function loginData(user) {
    Utils.setLocalStorageItem('currentUser', user)
    Auth.setToken(user.tokens.access.token)
    currentUserSubject.next(user);
    return user;
}

function logout() {
    localStorage.clear()
    currentUserSubject.next(null);
}
