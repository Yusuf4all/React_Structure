import React from "react";
import { NavLink } from "react-router-dom";
import { useTheme } from "../../../../theme/UseTheme";

export default function LogoSection() {
	const { theme } = useTheme();
    
	return (
		<div className="navbar-nav me-auto mb-2 mb-lg-0">
            <NavLink className="navbar-brand d-flex" to={"/"}>
                <div>
                    <img src={theme?.logoUrl} alt="" />
                    </div>
				<h1 className="nav-link logo-text" aria-current="page" href="#">
					Launch App
				</h1>
			</NavLink>
		</div>
	);
}
