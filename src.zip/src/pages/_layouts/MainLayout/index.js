import * as React from "react";
import Sidebar from "./Sidebar";

function MainLayout({ children }) {
	return (
		<>
			<div>
				{/* <Sidebar /> */}
				{/* ==========================  Divide main dashboard section   =========================================== */}
				{children}
			</div>
		</>
	);
}

export default MainLayout;
