import React from 'react'

function Sidebar() {
  return (
	<div><p className='sidebar'>Sidebar</p></div>
  )
}

export default Sidebar