import React from "react";
import LOGO from '../LogoSection'
function Header() {
  return (
    <div></div>
  )
}

export default Header


// class Header extends React.Component {
//     render() {
//         return (
//             <header className="themebg-color">
//                 <nav className="navbar navbar-expand-lg">
//                     <div className="container-fluid">
//                         <div>
//                             <LOGO />
//                         </div>

//                         <div>
//                             <button
//                                 className="navbar-toggler"
//                                 type="button"
//                                 data-bs-toggle="collapse"
//                                 data-bs-target="#navbarSupportedContent"
//                                 aria-controls="navbarSupportedContent"
//                                 aria-expanded="false"
//                                 aria-label="Toggle navigation"
//                             >
//                                 <span className="navbar-toggler-icon"></span>
//                             </button>

//                             <div
//                                 className="collapse navbar-collapse"
//                                 id="navbarSupportedContent"
//                             >
//                             </div>
//                         </div>

//                     </div>
//                 </nav>
//             </header>
//         );
//     }
// }

// export default Header;
