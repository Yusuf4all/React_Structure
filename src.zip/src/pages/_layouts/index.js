import React from "react";
import PropTypes from "prop-types";
import Header from "./MainLayout/Header";
import MainLayout from "./MainLayout";
import MultiThemeProvider from "../../theme/MultiThemeProvider";
import { GlobalStyles } from "../../theme/GlobalStyles";

export default function DefaultLayout({ children }) {
	return (
		<MultiThemeProvider>
			<GlobalStyles />
			<Header />
			<main>
				<MainLayout>{children}</MainLayout>
			</main>
		</MultiThemeProvider>
	);
}

DefaultLayout.propTypes = {
	children: PropTypes.element.isRequired,
};
