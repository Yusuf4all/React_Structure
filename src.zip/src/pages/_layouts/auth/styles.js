import styled from "styled-components";

export const Wrapper = styled.div`
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const Header = styled.div`
  background: #333;
  height: 10vh;
`;
