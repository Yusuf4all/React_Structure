import { useEffect } from "react";
import Auth from "../../utils/auth";
import axios from "axios";
import { useNavigate, useSearchParams } from "react-router-dom";
import config from "../../config";
import Utils from "../../utils";

function Login() {
	const navigate = useNavigate();
	const [searchParams] = useSearchParams();

	const {
		apiGateway: {
			URL,
			loginURL,
			endPoints: { VALIDATE_TOKEN },
		},
	} = config;

	useEffect(() => {
		if (Auth.getToken()) {
			navigate("/");
		} else {
			const token = searchParams.get("token");
			if (token) {
				handleValidateToken(token);
			} else {
				Auth.removeToken();
				window.open(loginURL, "_self");
			}
		}
	}, []);

	const handleValidateToken = async (token) => {
		try {
			const headers = {
				"Content-Type": "application/json",
				accessToken: token,
			};
			const result = await axios.post(
				`${URL}${VALIDATE_TOKEN}`,
				{},
				{
					headers: headers,
				}
			);

			if (result.data.statusCode === 200) {
				const ACCESS_TOKEN = result?.data?.data?.accessToken || "";
				if (ACCESS_TOKEN) {
					Utils.setSessionStorageItem("uToken", ACCESS_TOKEN);
					// const sessionId = Utils.extractValFromToken("sessionId");
					// Utils.setCookie("uSessCk", sessionId, 30);
					navigate("/");
				}
			} else {
				Auth.removeToken();
				window.open(loginURL, "_self");
			}
		} catch (error) {
			console.log("Error:- ", error);
		}
	};

	return (
		<div className="d-flex justify-content-center text-center">
			<h4>Please wait until we authenticate you...</h4>
		</div>
	);
}

export default Login;
