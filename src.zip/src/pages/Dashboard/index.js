import React from 'react'
import Conversation from '../../components/Conversation'

function Dashboard() {
  return (
	<div><Conversation/></div>
  )
}

export default Dashboard