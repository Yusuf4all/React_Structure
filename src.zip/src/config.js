const config = {
	apiGateway: {
		URL: process.env.REACT_APP_API_URL,
		conversationURL: process.env.REACT_APP_CONVERSATION_API_URL,
		directory: process.env.REACT_APP_DIRECTORY,
		loginURL: process.env.REACT_APP_LOGIN_URL,
		endPoints: {
			VALIDATE_TOKEN: "/auth/validateToken",
			CONVERSATION:"/conversation-v2"
		},
	},
};

export default config;
