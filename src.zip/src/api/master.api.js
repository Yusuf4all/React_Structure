import { MasterService } from "../services/master.service";
import config from "../config";

const {
	apiGateway: {
		endPoints: {
			CONVERSATION
		},
	},
} = config;

export const sendConversation = async (data) => {
	debugger
	const payload = {
		question:data
	}
	return await MasterService.post(CONVERSATION, payload)
}