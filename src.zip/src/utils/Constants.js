export const EMAIL_REGEX = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/

export const DEFAULT_THEME = {
	client_id: "C0001",
	name: "Hilbert",
	title: "Launch App",
	emailAddess: "hilbertstudentsupport@stackroute.com",
	contactNumber: "(716) 313 2650",
	logoUrl:
		"https://bootcamp.hilbert.edu/sites/default/files/inline-images/logo.png",
	favIconUrl: "https://bootcamp.hilbert.edu/themes/hilbert/favicon/hilbert.ico",
	policyLink: "https://bootcamp.hilbert.edu/privacy-policy?&",
	contactUsLink: "https://bootcamp.hilbert.edu/hilbert-support?&",
	termsLink: "https://bootcamp.hilbert.edu/terms-use?&",
	baseURL: "https://hilbert-learn.stackroute.com/",
	colors: {
		primary: "#2A92D1",
		primaryDark: "#034E9B",
		secondary: "#FDB726",
		textPrimary: "red",
		textSecondary: "#FFFFFF",
		navPrimary: "#323232",
		navSecondary: "#FAFAFA",
		navTextPrimary: "#FFFFFF",
		cardPrimary: "#f7f7f7",
		cardPrimaryLight: "#c2c2c2",
		cardPrimaryDark: "#E4E4E4",
		btnDefault: "#E4E4E4",
		btnPrimary: "#034E9B",
		btnSecondary: "#c2c2c2",
		btnSecondaryDark: "#5c5c5c",
		success: "#3BD923",
		footerPrimary: "#323232",
		footerTextPrimary: "#FAFAFA",
	},
	font: {
		thin: "Raleway-Thin",
		light: "Raleway-Light",
		medium: "Raleway-Medium",
		regular: "Raleway-Regular",
		bold: "Raleway-Bold",
	},
};

