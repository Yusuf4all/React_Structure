import { jwtDecode } from "jwt-decode";
class Utils {
	static tokenKey = "uToken";
	/**
	 * Common utils
	 */
	static extractValFromToken(key) {
		debugger
		const VALUE = sessionStorage.getItem(this.tokenKey);
		const tokenValue = jwtDecode(VALUE);
		return tokenValue[key]
	}

	static getDataFromToken() {
		const tokenData = this.getSessionStorageItem(this.tokenKey);
		return tokenData ? JSON.parse(window.atob(tokenData)) : null;
	}

	static setSessionStorageItem(key, value) {
		value = typeof value === "object" ? JSON.stringify(value) : value;
		return sessionStorage.setItem(key, value);
	}

	static getSessionStorageItem(key) {
		const VALUE = sessionStorage.getItem(key);
		return VALUE ? JSON.parse(VALUE) : null;
	}

	static removeSessionStorageItem(key) {
		return sessionStorage.removeItem(key);
	}

	static setCookie = (cname, cvalue, exdays) => {
		const d = new Date();
		d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
		let expires = "expires=" + d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	};
	static getCookie = (cname) => {
		let name = cname + "=";
		let ca = document.cookie.split(";");
		for (let i = 0; i < ca.length; i++) {
			let c = ca[i];
			while (c.charAt(0) === " ") {
				c = c.substring(1);
			}
			if (c.indexOf(name) === 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	};
}
export default Utils;
