class Auth {
    static tokenKey = "uToken";
    /**
     * Authenticate a user. Save a token string in Session Storage
     *
     * @param {string} token
     */
    static setToken(token) {
        sessionStorage.setItem(this.tokenKey, token)
    }
    /**
     * Get a token value.
     *
     * @returns {string}
     */
    static getToken() {
        return sessionStorage.getItem(this.tokenKey)
    }
    /**
     * Deauthenticate a user. Remove a token from Session Storage.
     *
     */
     static removeToken() {
         sessionStorage.removeItem(this.tokenKey) 
    }
    /**
     * Check if a user is authenticated - check if a token is saved in Session Storage
     *
     * @returns {boolean}
     */
    static isUserAuthenticated() {
        return sessionStorage.getItem(this.tokenKey) !== null
    }    
    
}

export default Auth;