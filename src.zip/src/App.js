import React, { useEffect } from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { useSelector } from "react-redux";
import Routes from "./routes";
import "./style.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Loader from "./components/common/Loader";

function App() {
	const isLoader = useSelector((state) => state.user.isLoader);
	return (
		<>
			<ToastContainer />
			<Loader isLoader={isLoader} />
			<Router>
				<Routes />
			</Router>
		</>
	);
}

export default App;
