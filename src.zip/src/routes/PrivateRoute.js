import React from "react";
import DefaultLayout from "../pages/_layouts";
import Auth from "../utils/auth";
import config from "../config";

export const PrivateRoute = ({ children }) => {
	if (Auth.isUserAuthenticated()) {
		return <DefaultLayout>{children}</DefaultLayout>;
	} else {
		const { apiGateway: { loginURL } } = config
			window.open(loginURL, "_self");
	}
};
