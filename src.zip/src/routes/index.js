import React from "react";
import { Routes } from "react-router-dom";
import { Route } from "react-router-dom";
import { PrivateRoute } from "./PrivateRoute";
import Dashboard from "../pages/Dashboard";
import Login from "../pages/Login";
export default function RoutesPath() {
	return (
		<Routes>
			<Route exact path="/login" element={<Login />} />
			<Route
				path="/"
				element={
					<PrivateRoute>
						<Dashboard />
					</PrivateRoute>
				}
			/>
		</Routes>
	);
}
