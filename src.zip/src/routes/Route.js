import React from "react";
import PropTypes from "prop-types";
import { Navigate } from "react-router-dom";
// import AuthLayout from '../pages/_layouts/auth'

export default function RouteWrapper({isPrivate,children}) {
    const signed = false;
    /**
     * Navigate user to SignIn page if he tries to access a private route
     * without authentication.
     */
    if (isPrivate && !signed) {
        return <Navigate to="/" />;
    }

    /**
     * Navigate user to Main page if he tries to access a non private route
     * (SignIn or SignUp) after being authenticated.
     */
    if (!isPrivate && signed) {
        return <Navigate to="/dashboard" />;
    }

    // const Layout = signed ? AuthLayout : AuthLayout;
    // const Layout = signed ? DefaultLayout : DefaultLayout;

    /**
     * If not included on both previous cases, Navigate user to the desired route.
     */
    // return <Layout>
    //     {children}
    // </Layout>
    return children
    
}

RouteWrapper.propTypes = {
    isPrivate: PropTypes.bool,
    // component: PropTypes.oneOfType([PropTypes.element, PropTypes.func]).isRequired
};

RouteWrapper.defaultProps = {
    isPrivate: false
};
