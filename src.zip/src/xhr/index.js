import axios from 'axios';
import Auth from '../utils/auth'
import config from '../config'
import { authenticationService } from '../services/authentication.service';
const { apiGateway: { URL, conversationURL } } = config;
const httpClient = axios.create({
    baseURL: conversationURL,
    withCredentials: true,
    timeout: 300000
});

httpClient.interceptors.request.use((config) => {
    const TOKEN = Auth.getToken()
    if (TOKEN) {
      config.headers['x-access-token'] = `${TOKEN}`;
    }
    return config;
  });

//add 401 based on root if possible
httpClient.interceptors.response.use(res => res, err => {    
    //alert(location.pathname);    
    if ([401,403].indexOf(err.response?.status) !== -1) {
        authenticationService.logout();
    }
    const error = (err.response && err.response.data.message) || err.message;
    if (axios.isCancel(err)) {
        return Promise.resolve(err.message);
    } else {
        return Promise.reject(error);
    }
});

export default httpClient;

