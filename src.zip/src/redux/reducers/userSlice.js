import { createSlice } from "@reduxjs/toolkit";
import Utils from "../../utils";

const user = Utils.getSessionStorageItem("currentUser");
const initialState = {
	user,	
	isLoader: false,
};

export const userSlice = createSlice({
	name: "user",
	initialState,
	reducers: {
		loginReducer: (state, action) => {
			state.user = action.payload;
		},
		logoutReducer: (state) => {
			state.user = null;
		},
		handleLoaderReducer: (state, action) => {
			state.isLoader = action.payload;
		},
	},
});

// Action creators are generated for each case reducer function
export const {
	loginReducer,
	logoutReducer,

	handleLoaderReducer,
} = userSlice.actions;

export default userSlice.reducer;
