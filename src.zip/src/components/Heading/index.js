import React from 'react'

function Heading({ level, className,style, children }) {
    const DYNAMIC_HEADING = `h${level}`

    return (
        <DYNAMIC_HEADING
            className={className}
            style={style}
        >{children}</DYNAMIC_HEADING>
    )
}

export default Heading