import React from 'react'
import { Oval } from "react-loader-spinner";
function Loader({ isLoader }) {
    return (
        <Oval
            height={60}
            width={60}
            color="#0061AF"
            wrapperClass="loader-style"
            visible={isLoader}
            ariaLabel="oval-loading"
            secondaryColor="#0072cb "
            strokeWidth={4}
            strokeWidthSecondary={4}
        />
    )
}

export default Loader