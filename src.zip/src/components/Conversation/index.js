import React, { useState, useEffect, useRef } from "react";
import chatLoader from "../../assets/images/chat-loader.gif";
import systemIcon from "../../assets/images/userIcon.png";
import userIcon from "../../assets/images/systemIcon.png";
import { toast } from "react-toastify";
import { Tooltip } from "react-tooltip";
import "react-tooltip/dist/react-tooltip.css";
import { sendConversation } from "../../api/master.api";

function Conversation() {
	const [messages, setMessages] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const [chatLoaderStatus, setChatLoaderStatus] = useState(false);
	const [showAlert, setShowAlert] = useState(false);
	const [query, setQuery] = useState("");

	const messageContainerRef = useRef(null);
	const inputRef = useRef(null);

	useEffect(() => {
		if (messages && messageContainerRef.current) {
			messageContainerRef.current.scrollTop =
				messageContainerRef.current.scrollHeight;
		}
	}, [messages]);

	useEffect(() => {
		inputRef.current && inputRef.current.focus();
	}, []);

	const resetDialog = () => {
		setQuery("");
		setShowAlert(false);
		setMessages([{ text: "" }]);
	};

	const handleQueryChange = (event) => {
		const {value} = event.target;
		const finaval = value.replace(/[\n\r]+/g, "");
		setQuery(finaval);
	};

	const addMessage = (text, isUser = false, isError = false) => {
		const newMessage = { text, isUser, isError };
		setMessages((prevMessages) => [...prevMessages, newMessage]);
	};


	const handleSubmit = async (event) => {
		event.preventDefault();
		addMessage(query, true);
		setIsLoading(true);
		setChatLoaderStatus(true);

		try {
			const res = await sendConversation(query)
			if (res.success) {
				let stringigyResponse = "";
				if (res.data?.success) {
					stringigyResponse =
						typeof res.data.data === "string"
							? res.data.data
							: JSON.stringify(res?.data?.data || "");
				} else {
					stringigyResponse =
						typeof res.data === "string"
							? res.data
							: JSON.stringify(res?.data || "");
				}

				addMessage(stringigyResponse);
				setChatLoaderStatus(false);
			}
		} catch (error) {
			console.error("API Error:", error);
			addMessage("Error occurred while making the API request", false, true); // Set error flag
		} finally {
			setIsLoading(false);
			setChatLoaderStatus(false);
			setQuery("");
			inputRef.current && inputRef.current.focus();
		}
	};

	return (
		<div style={{ display: "flex", justifyContent: "flex-end" }}>
			<div
				className="modal fade show "
				style={{ display: "block", backgroundColor: "rgba(0, 0, 0, 0.5)" }}
			>
				<div
					className="modal-dialog modal-dialog-centered newapp-modal queryapp-modal-dialog"
					style={{ maxWidth: "700px" }}
				>
					<div className="modal-content">
						<div className="modal-body">
							<div className="maxrow" ref={messageContainerRef}>
								<ul className="chatsection">
									<li className=" chatbar-row">
										{" "}
										<img
											src={userIcon}
											alt="AI"
											width="30"
											height="30"
											className="boticon"
										></img>
										<div className="content">'Hi there! How can I help ?'</div>
									</li>

									{messages.map((message, messageIndex) => (
										<>
											{!message.text ? null : (
												<>
													{message.isUser ? (
														<li className=" chatbar-row">
															{" "}
															<img
																src={systemIcon}
																alt="AI"
																width="30"
																height="30"
																className="boticon"
															></img>
															<div className="content">{message.text}</div>
														</li>
													) : (
														<li className="userrow">
															<img
																src={userIcon}
																alt="AI"
																width="30"
																height="30"
																className="boticon"
															></img>
															{message.text}
														</li>
													)}
												</>
											)}
										</>
									))}
								</ul>
								{isLoading && (
									<div
										style={{
											display: "flex",
											justifyContent: "center",
											padding: "16px",
										}}
									>
										<div className="spinner-border text-primary" role="status">
											{/* <span className="sr-only">Loading...</span> */}
										</div>
									</div>
								)}
							</div>

							<div className="inputrow">
								<div className="queryapp-inputrow">
									<textarea
										className="form-control form-control-custom-row"
										id="exampleFormControlTextarea1"
										placeholder="Type your question..."
										value={query}
										onChange={handleQueryChange}
										ref={inputRef}
										onKeyUp={(event) => {
											if (event.key === "Enter") {
												event.preventDefault();
												handleSubmit(event);
												// handleQueryChangeE(event);
											}
										}}
									></textarea>
								</div>
								<button type="submit" className="sub-secondarybtn ">
									{chatLoaderStatus ? (
										<img src={chatLoader} alt="" style={{ height: "26px" }} />
									) : (
										<svg
											xmlns="http://www.w3.org/2000/svg"
											className="icon icon-tabler icon-tabler-send"
											width="24"
											height="24"
											viewBox="0 0 24 24"
											stroke-width="2"
											stroke="#1e88e5"
											fill="none"
											stroke-linecap="round"
											stroke-linejoin="round"
										>
											<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
											<line x1="10" y1="14" x2="21" y2="3"></line>
											<path d="M21 3l-6.5 18a0.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a0.55 .55 0 0 1 0 -1l18 -6.5"></path>
										</svg>
									)}
								</button>
							</div>
						</div>

						<div className="modal-bottom-row queryapp-modalbottom">
							<button
								onClick={() => resetDialog()}
								className="clear_chat"
								tabindex="0"
								type="button"
								title="Clear Conversation"
							>
								<span className="MuiButton-startIcon MuiButton-iconSizeMedium css-1l6c7y9">
									<svg
										xmlns="http://www.w3.org/2000/svg"
										className="icon icon-tabler icon-tabler-eraser"
										width="24"
										height="24"
										viewBox="0 0 24 24"
										stroke-width="2"
										stroke="currentColor"
										fill="none"
										stroke-linecap="round"
										stroke-linejoin="round"
									>
										<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
										<path d="M19 20h-10.5l-4.21 -4.3a1 1 0 0 1 0 -1.41l10 -10a1 1 0 0 1 1.41 0l5 5a1 1 0 0 1 0 1.41l-9.2 9.3"></path>
										<path d="M18 13.3l-6.3 -6.3"></path>
									</svg>
								</span>
								Clear Chat
								<span className="MuiTouchRipple-root css-w0pj6f"></span>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}

export default Conversation;
